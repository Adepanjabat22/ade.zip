<div class="row">
			<div class="col-md-12">
				<center>Copyright &copy <?php echo date ('Y');?> Website UNIMED, design with <span class="glyphicon glyphicon-heart"></span> by ADE GANTENG SEJAGAT RAYA<br/>
				</center>
			</div>
			</div>
	</div><!-- Akhir FOOTER -->
		
<script src="../bootstrap/js/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../bootstrap/js/dataTables.bootstrap.min.js"></script>
<script src="../bootstrap/js/jquery.dataTables.js"></script>
<script src="../bootstrap/js/scripts.js"></script>

</script>
</body>
</html>