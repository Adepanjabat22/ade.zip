<!DOCTYPE html>
<html>
  <html lang="en">
  <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UNIMED PUNYA ADE</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
		<link href="bootstrap/css/dataTables.bootstrap.min.css" rel="stylesheet">
		<link href="bootstrap/css/styles.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top" id="scrollspy">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle Nav</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html"><b><img src="gambar/unimedlogo.png" width="35" height="28"> UNIVERSITAS SUMATERA UTARA</b></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
            <li>
							<a href="index.php"><b>DASHBOARD</b><span class="sr-only">(current)</span></a>
						</li>
            <li>
							<a href="tampil-dosen.php"><b>DATA DOSEN</b></a>
						</li>
						<li >
						<a href="tampil-pendaftaran.php"><b>DATA MAHASISWA BARU</b></a>
            </li>
            <li>
            <a href="contact.php"><b>KOTAK MASUK</b></a>
            </li>
            <li>
            <a href="tampil-user.php"><b>USER</b></a>
            </li>
            <li>
            <a href="../login.php"><b>LOG OUT</b></a>
            </li>
          
          </ul>
        </div>
        </div>
      </nav>